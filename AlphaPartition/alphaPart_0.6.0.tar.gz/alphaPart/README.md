# AlphaPart

AlphaPart R package
==============================

[![Build Status](https://travis-ci.org/janaobsteter/alphaPart.svg?branch=master)](https://travis-ci.org/janaobsteter/alphaPart)