#' Run example in alphaPart (see \code{\link[alphaPart]{alphaPart}}):

