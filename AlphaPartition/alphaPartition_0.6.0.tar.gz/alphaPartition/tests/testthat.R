library(testthat)
library(alphaPartition)

test_check("alphaPartition")

