library(testthat)
library(alphaPart)

test_check("alphaPart")

