#' Run example in alphaPartition (see \code{\link[alphaPartition]{alphaPartition}}):

